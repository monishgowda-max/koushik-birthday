function fireworks(){for(let i=0;i<120;i++){let s=document.createElement("div");s.className="spark";s.textContent=["✨","🎆","🎊"][i%3];
s.style.left=innerWidth/2+"px";s.style.top=innerHeight/2+"px";
s.style.setProperty("--x",(Math.random()*800-400)+"px");s.style.setProperty("--y",(Math.random()*600-300)+"px");
document.body.appendChild(s);setTimeout(()=>s.remove(),1500);}
alert("🎉 Happy Birthday Koshik! Have an amazing year ahead!");}